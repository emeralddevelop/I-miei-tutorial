package com.mystudio.mattiaferigutti.giocomotiplicationiapp;

import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class MainActivity extends AppCompatActivity
{

    private TextView mDomanda, mTimer, mResult;
    private Button bRisp1, bRisp2, bRisp3, bRisp4;
    private CountDownTimer countDownTimer;
    private Random random;
    private int ris = 0, point = 0, pointTotal = 0;
    private long mCurrentTime = 30000L;
    private static final String KEY = "key";

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mDomanda = findViewById(R.id.domanda);
        mTimer = findViewById(R.id.timer);
        mResult = findViewById(R.id.result);

        bRisp1 = findViewById(R.id.bRisp1);
        bRisp2 = findViewById(R.id.bRisp2);
        bRisp3 = findViewById(R.id.bRisp3);
        bRisp4 = findViewById(R.id.bRisp4);

        random = new Random();

        if (savedInstanceState != null) {
            mCurrentTime = savedInstanceState.getLong(KEY);
        }

        countDownTimer = new CountDownTimer(/*tempo di partenza*/mCurrentTime, /*intervallo di tempo*/1000L) {
            @Override
            public void onTick(long l) {
                //cosa fare ogni secondo
                mCurrentTime = mCurrentTime - 1000;
                mTimer.setText("Rimangono: " + l/1000 + " secondi");
            }

            @Override
            public void onFinish() {
                //cosa fare finito il tempo

                int percentuale = 0;
                try {
                    percentuale = (100 * point) / pointTotal;
                } catch (ArithmeticException e) {}

                mResult.setText("Hai fatto " + point + " punti su " + pointTotal + "\nHai fatto il " + percentuale + "% di risposte giuste");
                bRisp1.setEnabled(false);
                bRisp2.setEnabled(false);
                bRisp3.setEnabled(false);
                bRisp4.setEnabled(false);
                mTimer.setText("Hai finito il tempo");
            }
        }.start();

        List<Integer> lista = genereNumero();
        setTextButton(lista);
    }

    public void rispostaClick(View view)
    {
        pointTotal++;
        int id = view.getId();
        Button b = null;

        switch (id)
        {
            case R.id.bRisp1:
                b = bRisp1;
                isCorrectAnswer(b);
                break;

            case R.id.bRisp2:
                b = bRisp2;
                isCorrectAnswer(b);
                break;

            case R.id.bRisp3:
                b = bRisp3;
                isCorrectAnswer(b);
                break;

            case R.id.bRisp4:
                b = bRisp4;
                isCorrectAnswer(b);
                break;
        }

        List<Integer> lista = genereNumero();
        setTextButton(lista);
    }


    private List<Integer> genereNumero()
    {
        List<Integer> list = new ArrayList<>();

        for (int i=0; i<4; i++)
        {
            int randNum1 = random.nextInt(10)+1;
            int randNum2 = random.nextInt(10)+1;
            list.add(randNum1 * randNum2);

            if (i == 0)
            {
                mDomanda.setText("Qual'è il risultato di " + randNum1 + " x " + randNum2);
                ris = randNum1*randNum2;
            }
        }

        return list;
    }


    private boolean isCorrectAnswer(Button b)
    {
        if (b.getText().toString().equals(String.valueOf(ris))) {
            point++;
            return true;
        }

        return false;
    }

    private void setTextButton(List<Integer> list)
    {
        List<Integer> numList = new ArrayList<>();
        for (int i=0; i<4; i++)
        {
           int n = random.nextInt(4);
           if (!numList.contains(n)) {
               numList.add(n);
           }
           else i--;
        }

        bRisp1.setText(String.valueOf(list.get(numList.get(0))));
        bRisp2.setText(String.valueOf(list.get(numList.get(1))));
        bRisp3.setText(String.valueOf(list.get(numList.get(2))));
        bRisp4.setText(String.valueOf(list.get(numList.get(3))));
    }


    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putLong(KEY, mCurrentTime);
    }
}

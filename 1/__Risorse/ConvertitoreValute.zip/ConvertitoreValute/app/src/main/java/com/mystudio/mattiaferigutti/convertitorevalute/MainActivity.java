package com.mystudio.mattiaferigutti.convertitorevalute;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private Spinner spinner;
    private Button button;
    private TextView gbpText, eurText, usdText;
    private EditText editText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        spinner = findViewById(R.id.spinner);
        button = findViewById(R.id.button);
        gbpText = findViewById(R.id.gbpText);
        eurText = findViewById(R.id.euroText);
        usdText = findViewById(R.id.usdText);
        editText = findViewById(R.id.editText);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getValueSpinner();
            }
        });


    }

    private void getValueSpinner() {
        String selezione = String.valueOf(spinner.getSelectedItem());

        String valueString = editText.getText().toString().trim();
        double valueInt = Integer.parseInt(valueString);


        switch (selezione) {
            case "USD":

                String eur = String.valueOf(valueInt * 0.803953);
                eurText.setText(eur);

                String gbp = String.valueOf(valueInt * 0.721215 );
                gbpText.setText(gbp);

                usdText.setText(String.valueOf(valueInt));

                Toast.makeText(getApplicationContext(), /*message*/"USD", Toast.LENGTH_SHORT).show();
                break;

            case "EUR":

                String usd2 = String.valueOf(valueInt * 1.22593);
                usdText.setText(usd2);

                String gbp2 = String.valueOf(valueInt * 0.884510);
                gbpText.setText(gbp2);

                eurText.setText(String.valueOf(valueInt));

                Toast.makeText(getApplicationContext(), /*message*/"EUR", Toast.LENGTH_SHORT).show();
                break;

            case "GBP":

                String eur3 = String.valueOf(valueInt * 1.13043);
                eurText.setText(eur3);

                String usd3 = String.valueOf(valueInt * 1.38600);
                usdText.setText(usd3);

                gbpText.setText(String.valueOf(valueInt));

                Toast.makeText(getApplicationContext(), /*message*/"GBP", Toast.LENGTH_SHORT).show();
                break;
        }
    }

}

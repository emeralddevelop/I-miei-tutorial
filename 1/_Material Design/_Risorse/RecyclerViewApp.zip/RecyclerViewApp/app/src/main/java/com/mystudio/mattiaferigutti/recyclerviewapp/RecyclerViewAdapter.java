package com.mystudio.mattiaferigutti.recyclerviewapp;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

/**
 * Created by Mattia on 16/01/2018.
 */

public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.ViewHolder>
{

    private List<ModelData> users;
    private Context context;

    public RecyclerViewAdapter(List<ModelData> users, Context context) {
        this.users = users;
        this.context = context;
    }

    // facciamo l'inflate (gonfiaggio) lo riportiamo sul ViewHolder -> grazie al quale andrà a richiamare i vari componenti
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_row, parent, false);
        return new ViewHolder(v);
    }

    //impostare gli oggetti presi dalla lista popolata da classi "model"
    @Override
    public void onBindViewHolder(ViewHolder holder, final int position) {
        ModelData user = users.get(position);
        holder.nomeUser.setText(user.getName());
        holder.userImage.setImageResource(user.getUserImage());
        holder.touch_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(context, /*message*/"Position: " + position, Toast.LENGTH_SHORT).show();
            }
        });
    }

    //restituire la dimensione della lista
    @Override
    public int getItemCount() {
        return users.size();
    }

    //definiamo il ViewHolder
    public class ViewHolder extends RecyclerView.ViewHolder
    {
        private TextView nomeUser;
        private ImageView userImage;
        private LinearLayout touch_layout;

        public ViewHolder(View itemView) {
           super(itemView);
           nomeUser = itemView.findViewById(R.id.nomeText);
           userImage = itemView.findViewById(R.id.imageView);
            touch_layout = itemView.findViewById(R.id.touch_layout);
         }
    }
}

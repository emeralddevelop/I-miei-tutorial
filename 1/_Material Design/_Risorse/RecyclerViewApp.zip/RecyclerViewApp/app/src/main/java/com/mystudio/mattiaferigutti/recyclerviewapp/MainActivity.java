package com.mystudio.mattiaferigutti.recyclerviewapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity
{

    private RecyclerView recyclerView;
    private List<ModelData> users;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerView);
        users = new ArrayList<>();

        users.add(new ModelData("Pluto", R.drawable.pluto));
        users.add(new ModelData("Daffy Duck", R.drawable.daffy_duck));
        users.add(new ModelData("Topolino", R.drawable.topolino));

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(linearLayoutManager);

        recyclerView.setAdapter(new RecyclerViewAdapter(users, this));
        recyclerView.setHasFixedSize(true); //le cardView sono tutte delle stesse dimensioni

    }
}

package com.mystudio.mattiaferigutti.textfield;

import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.AppCompatEditText;
import android.view.View;

public class MainActivity extends AppCompatActivity
{

    private AppCompatEditText usernameEdit;
    private TextInputLayout usernameTextInput;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        usernameEdit = findViewById(R.id.username_editText);
        usernameTextInput = findViewById(R.id.username_textInput);

        usernameEdit.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View view, boolean b) {
                if (usernameEdit.getText().toString().isEmpty()) {
                    usernameTextInput.setErrorEnabled(true);
                    usernameTextInput.setError("inserisci un username");
                }
                else {
                    usernameTextInput.setErrorEnabled(false);
                }
            }
        });

    }
}

package com.mystudio.mattiaferigutti.buttonmaterial;

import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.AppCompatButton;
import android.view.View;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private AppCompatButton flatButton, RaisedButton;
    private FloatingActionButton floatButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        flatButton = findViewById(R.id.flatButton);
        RaisedButton = findViewById(R.id.raisedButton);
        floatButton = findViewById(R.id.floatButton);

        flatButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), /*message*/"Flat Button", Toast.LENGTH_SHORT).show();
            }
        });

        RaisedButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), /*message*/"Raised Button", Toast.LENGTH_SHORT).show();
            }
        });

        floatButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), /*message*/"Float Button", Toast.LENGTH_SHORT).show();
            }
        });

    }
}
